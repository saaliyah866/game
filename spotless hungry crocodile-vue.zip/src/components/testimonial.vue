<template>
  <div class="thq-section-padding">
    <div class="testimonial-max-width thq-section-max-width">
      <div class="testimonial-container10">
        <h2 class="thq-heading-2">{{ heading1 }}</h2>
        <span class="testimonial-text11 thq-body-small">{{ content1 }}</span>
      </div>
      <div class="thq-grid-2">
        <div class="thq-animated-card-bg-2">
          <div class="thq-animated-card-bg-1">
            <div data-animated="true" class="thq-card testimonial-card1">
              <div class="testimonial-container12">
                <img
                  :alt="author1Alt"
                  :src="author1Src"
                  class="testimonial-image1"
                />
                <div class="testimonial-container13">
                  <strong class="thq-body-large">{{ author1Name }}</strong>
                  <span class="thq-body-small">{{ author1Position }}</span>
                </div>
              </div>
              <span class="testimonial-text14 thq-body-small">{{ review1 }}</span>
            </div>
          </div>
        </div>
        <div class="thq-animated-card-bg-2">
          <div class="thq-animated-card-bg-1">
            <div data-animated="true" class="thq-card testimonial-card2">
              <div class="testimonial-container14">
                <img
                  :alt="author2Alt"
                  :src="author2Src"
                  class="testimonial-image2"
                />
                <div class="testimonial-container15">
                  <strong class="thq-body-large">{{ author2Name }}</strong>
                  <span class="thq-body-small">{{ author2Position }}</span>
                </div>
              </div>
              <span class="testimonial-text17 thq-body-small">{{ review2 }}</span>
            </div>
          </div>
        </div>
        <div class="thq-animated-card-bg-2">
          <div class="thq-animated-card-bg-1">
            <div data-animated="true" class="thq-card testimonial-card3">
              <div class="testimonial-container16">
                <img
                  :alt="author3Alt"
                  :src="author3Src"
                  class="testimonial-image3"
                />
                <div class="testimonial-container17">
                  <strong class="thq-body-large">{{ author3Name }}</strong>
                  <span class="thq-body-small">{{ author3Position }}</span>
                </div>
              </div>
              <span class="testimonial-text20 thq-body-small">{{ review3 }}</span>
            </div>
          </div>
        </div>
        <div class="thq-animated-card-bg-2">
          <div class="thq-animated-card-bg-1">
            <div data-animated="true" class="thq-card testimonial-card4">
              <div class="testimonial-container18">
                <img
                  :alt="author4Alt"
                  :src="author4Src"
                  class="testimonial-image4"
                />
                <div class="testimonial-container19">
                  <strong class="thq-body-large">{{ author4Name }}</strong>
                  <span class="thq-body-small">{{ author4Position }}</span>
                </div>
              </div>
              <span class="testimonial-text23 thq-body-small">{{ review4 }}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'Testimonial',
  props: {
    heading1: {
      type: String,
      default: 'Testimonials',
    },
    author4Src: {
      type: String,
      default:
        'https://images.unsplash.com/photo-1534143826428-81fc61582afd?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTc0MzY2OTIzM3w&ixlib=rb-4.0.3&q=80&w=1080',
    },
    author4Name: {
      type: String,
      default: 'Sarah Williams',
    },
    author3Alt: {
      type: String,
      default: 'David Johnson Image',
    },
    author3Position: {
      type: String,
      default: 'New Player',
    },
    content1: {
      type: String,
      default:
        'See what our customers have to say about their experience with our casino bonuses.',
    },
    author1Src: {
      type: String,
      default:
        'https://images.unsplash.com/photo-1637858868799-7f26a0640eb6?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTc0MzY2OTIzMnw&ixlib=rb-4.0.3&q=80&w=1080',
    },
    author3Name: {
      type: String,
      default: 'David Johnson',
    },
    author2Alt: {
      type: String,
      default: 'Jane Smith Image',
    },
    author4Position: {
      type: String,
      default: 'Frequent Player',
    },
    author2Position: {
      type: String,
      default: 'VIP Player',
    },
    review1: {
      type: String,
      default:
        "I've never had so much fun playing at an online casino before. The bonuses really helped me boost my winnings!",
    },
    review2: {
      type: String,
      default:
        'The surprises that came with the casino bonuses were truly unexpected and delightful. Thank you!',
    },
    author1Alt: {
      type: String,
      default: 'John Doe Image',
    },
    author1Position: {
      type: String,
      default: 'Regular Player',
    },
    review3: {
      type: String,
      default:
        'As a new player, the bonuses gave me a great head start and made my gaming experience more exciting.',
    },
    author1Name: {
      type: String,
      default: 'John Doe',
    },
    author2Src: {
      type: String,
      default:
        'https://images.unsplash.com/photo-1674913070707-faa70b0b5371?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTc0MzY2OTIzM3w&ixlib=rb-4.0.3&q=80&w=1080',
    },
    author4Alt: {
      type: String,
      default: 'Sarah Williams Image',
    },
    author3Src: {
      type: String,
      default:
        'https://images.unsplash.com/photo-1564463836146-4e30522c2984?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w5MTMyMXwwfDF8cmFuZG9tfHx8fHx8fHx8MTc0MzY2OTIzM3w&ixlib=rb-4.0.3&q=80&w=1080',
    },
    author2Name: {
      type: String,
      default: 'Jane Smith',
    },
    review4: {
      type: String,
      default:
        "I've been playing at various online casinos, but the bonuses here are by far the most rewarding. Highly recommended!",
    },
  },
}
</script>

<style scoped>
.testimonial-max-width {
  display: flex;
  align-items: center;
  flex-direction: column;
}
 
.testimonial-container10 {
  gap: var(--dl-layout-space-unit);
  display: flex;
  max-width: 600px;
  align-items: center;
  margin-bottom: var(--dl-layout-space-fourunits);
  flex-direction: column;
}
 
.testimonial-text11 {
  text-align: center;
}
 
.testimonial-container12 {
  gap: var(--dl-layout-space-unit);
  display: flex;
  align-self: flex-start;
  align-items: center;
  flex-direction: row;
  justify-content: center;
}
 
.testimonial-image1 {
  width: var(--dl-layout-size-small);
  height: var(--dl-layout-size-small);
  object-fit: cover;
  border-radius: var(--dl-layout-radius-round);
}
 
.testimonial-container13 {
  display: flex;
  align-items: flex-start;
  flex-direction: column;
  justify-content: center;
}
 
.testimonial-text14 {
  text-align: left;
}
 
.testimonial-container14 {
  gap: var(--dl-layout-space-unit);
  display: flex;
  align-self: flex-start;
  align-items: center;
  flex-direction: row;
  justify-content: center;
}
 
.testimonial-image2 {
  width: var(--dl-layout-size-small);
  height: var(--dl-layout-size-small);
  object-fit: cover;
  border-radius: var(--dl-layout-radius-round);
}
 
.testimonial-container15 {
  display: flex;
  align-items: flex-start;
  flex-direction: column;
  justify-content: center;
}
 
.testimonial-text17 {
  text-align: left;
}
 
.testimonial-container16 {
  gap: var(--dl-layout-space-unit);
  display: flex;
  align-self: flex-start;
  align-items: center;
  flex-direction: row;
  justify-content: center;
}
 
.testimonial-image3 {
  width: var(--dl-layout-size-small);
  height: var(--dl-layout-size-small);
  object-fit: cover;
  border-radius: var(--dl-layout-radius-round);
}
 
.testimonial-container17 {
  display: flex;
  align-items: flex-start;
  flex-direction: column;
  justify-content: center;
}
 
.testimonial-text20 {
  text-align: left;
}
 
.testimonial-container18 {
  gap: var(--dl-layout-space-unit);
  display: flex;
  align-self: flex-start;
  align-items: center;
  flex-direction: row;
  justify-content: center;
}
 
.testimonial-image4 {
  width: var(--dl-layout-size-small);
  height: var(--dl-layout-size-small);
  object-fit: cover;
  border-radius: var(--dl-layout-radius-round);
}
 
.testimonial-container19 {
  display: flex;
  align-items: flex-start;
  flex-direction: column;
  justify-content: center;
}
 
.testimonial-text23 {
  text-align: left;
}
 
@media(max-width: 991px) {
  .testimonial-container10 {
    margin-bottom: var(--dl-layout-space-threeunits);
  }
}
 
@media(max-width: 767px) {
  .testimonial-container10 {
    margin-bottom: var(--dl-layout-space-oneandhalfunits);
  }
  .testimonial-card1 {
    width: 100%;
  }
  .testimonial-card2 {
    width: 100%;
  }
  .testimonial-card3 {
    width: 100%;
  }
  .testimonial-card4 {
    width: 100%;
  }
}
</style>
